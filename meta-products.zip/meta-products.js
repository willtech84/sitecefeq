const BASE_URL = 'https://cefeqsc.net.br';
const PAGE_SIZE = 1000;
const CSV_HEADER = 'id,title,description,availability,condition,price,link,image_link,brand';

function csvEscape(value) {
  const text = String(value ?? '');
  return `"${text.replace(/"/g, '""')}"`;
}

function cleanDescription(value, fallback) {
  const description = String(value || fallback)
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/\s+/g, ' ')
    .trim();

  return description || fallback;
}

function slugify(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function absoluteImageUrl(images) {
  const image = Array.isArray(images)
    ? images.find(value => typeof value === 'string' && value.trim())
    : images;
  if (typeof image !== 'string' || !image.trim()) {
    return null;
  }

  const path = image.trim();
  return /^https?:\/\//i.test(path)
    ? path
    : `${BASE_URL}/${path.replace(/^\/+/, '')}`;
}

function formatProduct(product) {
  const id = String(product.id ?? '').trim();
  const title = String(product.name ?? '').trim();
  const regularPrice = Number(product.price_cash || product.price || 0);
  const promotionalPrice = Number(product.promotional_price || 0);
  const price = promotionalPrice > 0 && promotionalPrice < regularPrice
    ? promotionalPrice
    : regularPrice;
  const imageLink = absoluteImageUrl(product.images);

  if (!id || !title || !Number.isFinite(price) || price <= 0 || !imageLink) {
    console.warn(`Produto ignorado no feed por falta de ID, título, preço válido ou imagem (ID: ${id || 'vazio'}).`);
    return null;
  }

  const slug = slugify(title);
  const link = `${BASE_URL}/produto.html?id=${encodeURIComponent(id)}${slug ? `&slug=${encodeURIComponent(slug)}` : ''}`;
  const availability = product.available === true
    || product.available === 'true'
    || product.available === 1
    ? 'in stock'
    : 'out of stock';
  const brand = String(product.brand || '').trim() || 'Generic';

  return [
    id,
    title,
    cleanDescription(product.description, `${title} - Ferramenta profissional.`),
    availability,
    'new',
    `${price.toFixed(2)} BRL`,
    link,
    imageLink,
    brand
  ].map(csvEscape).join(',');
}

async function fetchProducts(supabaseUrl, supabaseKey) {
  const products = [];
  const fields = 'id,name,description,available,price_cash,price,promotional_price,images,brand';

  for (let offset = 0; ; offset += PAGE_SIZE) {
    const url = new URL('/rest/v1/products', supabaseUrl);
    url.searchParams.set('select', fields);
    url.searchParams.set('order', 'id.asc');

    const response = await fetch(url, {
      headers: {
        apikey: supabaseKey,
        Authorization: `Bearer ${supabaseKey}`,
        'Range-Unit': 'items',
        Range: `${offset}-${offset + PAGE_SIZE - 1}`
      }
    });

    if (!response.ok) {
      const details = await response.text();
      throw new Error(`Supabase respondeu ${response.status}: ${details.slice(0, 500)}`);
    }

    const page = await response.json();
    if (!Array.isArray(page)) {
      throw new Error('Resposta inesperada do Supabase ao buscar produtos.');
    }

    products.push(...page);
    if (page.length < PAGE_SIZE) break;
  }

  return products;
}

exports.handler = async function handler() {
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseKey = process.env.SUPABASE_KEY || process.env.SUPABASE_ANON_KEY;

  if (!supabaseUrl || !supabaseKey) {
    console.error('Configure SUPABASE_URL e SUPABASE_KEY (ou SUPABASE_ANON_KEY) nas variáveis do Netlify.');
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
      body: 'Feed indisponível: configuração do Supabase ausente.'
    };
  }

  try {
    const products = await fetchProducts(supabaseUrl, supabaseKey);
    const rows = products.map(formatProduct).filter(Boolean);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': 'inline; filename="meta-products.csv"',
        'Cache-Control': 'public, max-age=60',
        'X-Content-Type-Options': 'nosniff'
      },
      body: [CSV_HEADER, ...rows].join('\n')
    };
  } catch (error) {
    console.error('Falha ao gerar feed de produtos:', error);
    return {
      statusCode: 502,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
      body: 'Feed indisponível: erro ao consultar os produtos.'
    };
  }
};
